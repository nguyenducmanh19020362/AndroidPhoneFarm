﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Code.Model
{
    public class View
    {
        public string classname { get; set; }
        public bool clickable { get; set; }
        public string resourceid{ get; set; }
        public bool scrollable { get; set; }
        public string text { get; set; }
        public int x { get; set; }
        public int y { get; set; }

        public View(XmlNode node)
        {
            this.text = node.Attributes["text"].InnerText;
            this.classname = node.Attributes["class"].InnerText;
            this.resourceid = node.Attributes["resource-id"].InnerText;
            this.clickable = node.Attributes["clickable"].InnerText == "true" ? true : false;
            this.scrollable = node.Attributes["scrollable"].InnerText == "true" ? true : false;
            string bound = node.Attributes["bounds"].InnerText;
            GetXY(bound);
        }
        private void GetXY(string bound)
        {
            int i = 1;
            int xtop = 0;
            while (bound[i] != ',')
            {
                xtop *= 10;
                xtop += bound[i] - '0';
                i++;
            }
            i++;
            int ytop = 0;
            while (bound[i] != ']')
            {
                ytop *= 10;
                ytop += bound[i] - '0';
                i++;
            }
            i += 2;
            int xdown = 0;
            while (bound[i] != ',')
            {
                xdown *= 10;
                xdown += bound[i] - '0';
                i++;
            }
            i++;
            int ydown = 0;
            while (bound[i] != ']')
            {
                ydown *= 10;
                ydown += bound[i] - '0';
                i++;
            }
            x = (xtop + xdown) / 2;
            y = (ytop + ydown) / 2;
        }
    }
}
