﻿using Code.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Code.Model
{
    public class TextMatcher: FindMatcher
    {
        private string text;

        public bool match(XmlNode node)
        {
            var a = node.Attributes["text"].InnerText == text;
            var b = node.Attributes["resource-id"].InnerText == text;
            if (a || b)
            {
                Console.WriteLine(node.Attributes["text"].InnerText + ", " + text);
                Console.WriteLine(node.Attributes["resource-id"].InnerText + ", " + text);
            }
            return a || b;
        }

        public TextMatcher(string text)
        {
            this.text = text;
        }
    }
}
