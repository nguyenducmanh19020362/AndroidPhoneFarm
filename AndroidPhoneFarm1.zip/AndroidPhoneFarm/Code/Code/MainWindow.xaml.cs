﻿using Code.Interface;
using Code.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace Code
{
    
    public class ToaDoView
    {
        public ToaDoView()
        {
            this.x = 0;
            this.y = 0;
        }
        public ToaDoView(ToaDoView a)
        {
            this.x = a.x;
            this.y = a.y;
        }
        public int x { get; set; }
        public int y { get; set; }
    }
    public partial class MainWindow : Window
    {
        public string filename = "D://VSCode//view.xml";
        public System.Diagnostics.Process process = new System.Diagnostics.Process();
        public System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();

        public void setUpstartInfo()
        {
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
        }
        public void getInfoView()
        {
            string command = "/k Adb shell uiautomator dump /sdcard/view.xml && Adb pull /sdcard/view.xml D:\\VSCode";
            startInfo.Arguments = command;
            process.StartInfo = startInfo;
            process.Start();
            Thread.Sleep(1000);
        }

        //Hàm để mở trang tạo tài khoản Google
        public void intentGoogleAccountView()
        {
            string command = "/k adb shell am start -a \"android.settings.ADD_ACCOUNT_SETTINGS\" --esa \"account_types\" \"com.google\"";
            startInfo.Arguments = command;
            process.StartInfo = startInfo;
            process.Start();
            getInfoView();
        }

        //Hàm để chuyển sang nhập tên họ
        public void ClickTaoTaiKhoan()
        {
            Thread.Sleep(2000);
            Click("Tạo tài khoản");
            Click("Cho bản thân tôi");
        }

        public void NhapTenHo()
        {
            int milliseconds = 1000;
            //click vào input text họ
            Click("lastName");

            //nhập họ
            string commandInputText = "/k adb shell input text ";
            string lastName = "\"Nguyen\"";
            string firstName = "\"Manh\"";
            Thread.Sleep(milliseconds);
            startInfo.Arguments = commandInputText + lastName;
            process.StartInfo = startInfo;
            process.Start();

            //click input text tên
            Click("firstName");

            //nhập tên
            Thread.Sleep(milliseconds);
            startInfo.Arguments = commandInputText + firstName;
            process.StartInfo = startInfo;
            process.Start();

            //nhấn back
            Thread.Sleep(milliseconds);
            string commandBack = "/k adb shell input keyevent 4";
            startInfo.Arguments = commandBack;
            process.StartInfo = startInfo;
            process.Start();

            Thread.Sleep(milliseconds);
            Click("Tiếp theo");
            Thread.Sleep(milliseconds);
            Click("Tiếp theo");
        }

        public void nhapThongTinCoBan()
        {
            Click("day");
            nhap("09");
            Click("month");
            Click("Tháng 3");
            Click("year");
            nhap("2001");
            Click("gender");
            Click("Nam");
            Click("Tiếp theo");
        }

        public void nhapTenVaMatKhau()
        {
            Thread.Sleep(1000);
            nhap("conmeobeotk123");
            Click("Tiếp theo");
            Thread.Sleep(1000);
            nhap("Password@123");
            Click("Tiếp theo");
        }

        public void nhap(string txt)
        {
            string commandInputText = "/k adb shell input text ";
            Thread.Sleep(1000);
            startInfo.Arguments = commandInputText + txt;
            process.StartInfo = startInfo;
            process.Start();

            Thread.Sleep(1000);
            string commandBack = "/k adb shell input keyevent 4";
            startInfo.Arguments = commandBack;
            process.StartInfo = startInfo;
            process.Start();
        }

        public void Click(string txt)
        {
            for (int i = 0; i < 15; i++)
            {
                Thread.Sleep(500);
                getInfoView();
                ToaDoView toado = layToaDoView(txt);
                if (toado.x != 0 && toado.y != 0)
                {
                    string command = "/k adb shell input tap " + toado.x + " " + toado.y;
                    startInfo.Arguments = command;
                    process.StartInfo = startInfo;
                    process.Start();
                    break;
                }
            }
        }

        public View findNode(XmlNode node, FindMatcher matcher)
        {
            if (matcher.match(node))
            {
                return new View(node);
            }
            foreach (XmlNode n in node.ChildNodes)
            {
                var founed = findNode(n, matcher);
                if (founed != null)
                {
                    return founed;
                }
            }
            return null;
        }
        public MainWindow()
        {
            InitializeComponent();
            setUpstartInfo();
            intentGoogleAccountView();
            ClickTaoTaiKhoan();
            NhapTenHo();
            nhapThongTinCoBan();
            nhapTenVaMatKhau();
        }

        private void Button_Click(object sender, RoutedEventArgs e, String txt)
        {
            
        }

        public ToaDoView layToaDoView(String txt)
        {
            var doc = new XmlDocument();
            doc.Load(filename);
            View view = findNode(doc.DocumentElement.FirstChild, new TextMatcher(txt));
            ToaDoView result = new ToaDoView();
            if (view != null)
            {
                txtClassname.Text = view.classname;
                txtClickable.Text = view.clickable.ToString();
                txtResourceId.Text = view.resourceid.ToString();
                txtScrollable.Text = view.scrollable.ToString();
                txtX.Text = view.x.ToString();
                txtY.Text = view.y.ToString();
                result.x = view.x;
                result.y = view.y;
            }
            return result;
        }
    }
}
