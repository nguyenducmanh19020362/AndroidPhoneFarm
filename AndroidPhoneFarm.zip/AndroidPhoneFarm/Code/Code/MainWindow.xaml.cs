﻿using Code.Interface;
using Code.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace Code
{
    
    public partial class MainWindow : Window
    {
        public string filename = "D://AndroidPhoneFarm//view.xml";
        public View findNode(XmlNode node, FindMatcher matcher)
        {
            if (matcher.match(node))
            {
                return new View(node);
            }
            foreach (XmlNode n in node.ChildNodes)
            {
                var founed = findNode(n, matcher);
                if (founed != null)
                {
                    return founed;
                }
            }
            return null;
        }
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var doc = new XmlDocument();
            doc.Load(filename);
            string txt = txtText.Text;
            View view = findNode(doc.DocumentElement.FirstChild, new TextMatcher(txt));
            if (view != null)
            {
                txtClassname.Text = view.classname;
                txtClickable.Text = view.clickable.ToString();
                txtResourceId.Text = view.resourceid.ToString();
                txtScrollable.Text = view.scrollable.ToString();
                txtX.Text = view.x.ToString();
                txtY.Text = view.y.ToString();
            }
            else
            {
                MessageBox.Show("Không tồn tại view.");
            }
        }
    }
}
